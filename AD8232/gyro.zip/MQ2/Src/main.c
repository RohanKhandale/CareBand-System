#include "stm32f4xx.h" // Include header file for your specific STM32 series (e.g., stm32f4xx.h)

void ADC1_Init(void);
uint16_t ADC1_Read(void);

int main(void) {
    uint16_t mq2_value;

    // Initialize the ADC
    ADC1_Init();

    while (1) {
        // Read the sensor value
        mq2_value = ADC1_Read();

        // You can use a debugger to view mq2_value in real-time
        // or implement UART transmission to see values on a serial monitor
        // (UART setup not included in this basic example)

        // Simple software delay
        for (uint32_t i = 0; i < 500000; i++);
    }
}

void ADC1_Init(void) {
    // 1. Enable the clock for GPIO Port A
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    // 2. Configure PA0 as analog mode (MODER 11)
    // Clear bits 0 and 1 for PA0
    GPIOA->MODER &= ~(GPIO_MODER_MODER0);
    // Set both bits to 1 (11 binary) for analog mode
    GPIOA->MODER |= (GPIO_MODER_MODER0);

    // 3. Enable the clock for ADC1
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    // 4. Configure ADC parameters (e.g., resolution, continuous mode)
    // Set 12-bit resolution (default, all bits 00 in RES[1:0] field)
    ADC1->CR2 &= ~ADC_CR2_CONT; // Ensure continuous conversion mode is off for polling

    // 5. Configure the sequence register to read from Channel 0 (PA0) as the first and only conversion
    ADC1->SQR3 |= (0U << 0); // SQ1[4:0] = 0 (Channel 0)

    // 6. Set sampling time for Channel 0 (e.g., 3 cycles is the minimum, use longer for stability)
    // For a robust reading, a longer sampling time is better.
    ADC1->SMPR2 |= (0U << 0); // SMP0[2:0] = 0 (3 cycles) - Check datasheet for better values

    // 7. Enable the ADC
    ADC1->CR2 |= ADC_CR2_ADON;
}

uint16_t ADC1_Read(void) {
    // 1. Start the conversion by setting SWSTART bit
    ADC1->CR2 |= ADC_CR2_SWSTART;

    // 2. Wait for the conversion to complete (EOC flag)
    while (!(ADC1->SR & ADC_SR_EOC));

    // 3. Read the converted value from the Data Register (DR)
    // Reading DR automatically clears the EOC flag
    return ADC1->DR;
}
